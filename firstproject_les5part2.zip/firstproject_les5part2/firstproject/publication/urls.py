from django.urls import path
from publication.views import create_image, archive_image, page_publication


urlpatterns = [
    path('', page_publication),
    path('create/', create_image),
    path('archive/', archive_image)
]