from django.shortcuts import render
from django.http import HttpResponse


def create_image(request):
    return HttpResponse('<h1>create_image</h1>')  #сторінка для додавання зображення

def archive_image(request):
    return HttpResponse('<h1>archive_image</h1>') #сторінка для архіву зображення

def page_publication(request):
    return HttpResponse('<h2>This page is for publication image</h2') #домашня сторінка для розділу публікації