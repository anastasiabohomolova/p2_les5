from django.db import models

# Create your models here.

class Post(models.Model):
    title = models.CharField(max_length=40)
    content = models.TextField()
    update = models.DateTimeField(auto_now=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    file_for_content = models.FileField()          #файл, є стрічкою/зображенням, додаткова файлова інформація до контенту
    quantity_content = models.IntegerField()       #цифрове поле, ціле число, вказуватиме кількість контенту



    def __str__(self):
        return self.title